function setup() {
  createCanvas(550, 600);
}



function draw() {
  background('#FFCC99');
  stroke('#000000');
  strokeWeight(3.0);
  strokeCap(ROUND);
  fill('#FFCCCC');
  ellipse(130,120,100,80);
  ellipse(375,130,100,80);
  ellipse(100,400,110,100);
  ellipse(400,400,110,100);
  ellipse(250,425,330,330);
  ellipse(250,225,320,280);
  fill('#FF9999');
  ellipse(270,270,100,100);
  ellipse(230,270,100,100);
  ellipse(250,300,50,100)
  ellipse(250,270,170,100);
  fill('#993333');
  ellipse(210,270,40,50);
  ellipse(280,270,40,50);
  fill('#FFFFFF');
  ellipse(170,190,55,70);
  ellipse(320,190,55,70);
  fill('#0099CC');
  ellipse(170,195,40,47);
  ellipse(320,195,40,47);
  fill('#000000');
  ellipse(170,195,20,25);
  ellipse(320,195,20,25);
  fill('#FFFFFF');
  ellipse(178,187,15,15);
  ellipse(328,187,15,15);
  fill('#FFFFFF');
  ellipse(168,205,10,10);
  ellipse(318,205,10,10);
  fill('#FF9999');
  arc(190,555,110,100,80,180);
  arc(310,555,110,100,30,350);

    strokeWeight(6.0);
  strokeCap(ROUND);
  stroke('#FF9999');
  
line(150,430,180,410);
  line(180,410,210,430);
  line(210,430,240,410);
  line(240,410,270,430);
  line(270,430,300,410);
  line(300,410,330,430);
  
  line(150,480,180,460);
  line(180,460,210,480);
  line(210,480,240,460);
  line(240,460,270,480);
  line(270,480,300,460);
  line(300,460,330,480);
  
  line(440,375,425,400);
  line(425,400,445,415);  
  line(55,380,75,400);
  line(75,400,51,415);

  line(130,120,98,125);
  line(123,120,133,100);
  line(370,125,380,105)
  line(378,125,395,130);
  

textSize(60);
textFont('monospace');
text('Oink! Oink!', 85, 60);





}
  
  
  
  
  
  
  
  
  
  
  
  

